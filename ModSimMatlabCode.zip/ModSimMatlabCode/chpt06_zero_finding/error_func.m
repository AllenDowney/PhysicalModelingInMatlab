function res = error_func(x)
    res = x.^2 - 2.*x -3;
end

function y = calls_f_func
    %f = 0
    f = f + 1;
    y = f;
end

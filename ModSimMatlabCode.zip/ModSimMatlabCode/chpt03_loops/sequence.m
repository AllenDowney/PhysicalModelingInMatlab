% Compute the first 10 elements of a geometric sequence

for i=1:10
    a = 1*(1/2)^(i-1)
end

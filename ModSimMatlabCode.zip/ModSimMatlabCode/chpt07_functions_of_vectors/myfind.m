% Finds the index of the first 0 in a vector.

function res = myfind(X)
    for i=1:length(X)
        if X(i) == 0
            ans = i
            break
        end
    end
end


% Squares the elements of a vector.

function res = myapply(X)
    for i=1:length(X)
        Y(i) = X(i)^2;
    end
    res = Y;
end


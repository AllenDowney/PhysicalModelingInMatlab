% Compute the hypoteneuse of a right triangle.

function res = mydiff(V)
    D(1) = V(1);
    for i = 2:length(V)
        D(i) = V(i) - V(i-1);
    end
    res = D;
end

% Compute Manhattan distance to a point on the unit circle

function res = myfunc(x)
    s = sin(x);
    c = cos(x);
    res = abs(s) + abs(c);
end


# Physical Modeling in MATLAB

*Physical Modeling in MATLAB* is an introduction to programming in MATLAB and simulation of physical systems by Allen B. Downey.

It is available from https://greenteapress.com/wp/physical-modeling-in-matlab/

# Physical Modeling in MATLAB

Code for *Physical Modeling in MATLAB* by Allen B. Downey, an introduction to programming in MATLAB and simulation of physical systems.

The book is available from https://greenteapress.com/wp/physical-modeling-in-matlab/ and its source and code from https://github.com/AllenDowney/PhysicalModelingInMatlab

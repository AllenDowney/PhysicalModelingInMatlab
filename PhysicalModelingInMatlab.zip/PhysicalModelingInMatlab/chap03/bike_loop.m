% Simulates the bike share system for one month

b = 100
c = 100

for i=1:30
    bike_update
end
